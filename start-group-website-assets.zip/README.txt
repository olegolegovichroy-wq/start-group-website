Add this block before the Contacts section:
--------------------------------------------------
<section id="director">
  <div class="wrap">
    <h2 data-i18n="dir_title">Повідомлення від директора</h2>
    <div class="grid">
      <div class="card" style="grid-column:span 6;min-width:280px">
        <picture>
          <source srcset="start-group-director.webp" type="image/webp">
          <img src="start-group-director.jpg" alt="Oleg Roi, Director of Start Group Limited" style="width:100%;border-radius:12px;border:1px solid var(--line)"/>
        </picture>
      </div>
      <div class="card" style="grid-column:span 6;min-width:260px;display:flex;flex-direction:column;justify-content:center">
        <blockquote style="font-size:20px;line-height:1.4;margin:0 0 10px" data-i18n="dir_quote">Наша стратегія — втілювати ваші ідеї в реальність.</blockquote>
        <div class="muted"><strong>Oleg Roi</strong> — <span data-i18n="dir_role">Директор, Start Group Limited</span></div>
      </div>
    </div>
  </div>
</section>

Add these keys to i18n dictionaries:
--------------------------------------------------
UK:
  dir_title: "Повідомлення від директора"
  dir_quote: "Наша стратегія — втілювати ваші ідеї в реальність."
  dir_role: "Директор, Start Group Limited"
EN:
  dir_title: "Message from the Director"
  dir_quote: "Our strategy is to bring your ideas into reality."
  dir_role: "Director, Start Group Limited"

Certificate hint: place the file next to index.html and use:
  <img class="certificate" src="start-group-certificate.jpg" alt="Certificate of Incorporation — Start Group Limited"/>